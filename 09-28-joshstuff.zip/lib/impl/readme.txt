This is a folder for internal usage. The Codename One plugin uses these directories 
to properly compile your application with 3rd party libraries.